/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import ma.projet.classes.Employe;
import ma.projet.services.EmployeService;

/**
 *
 * @author PC
 */
public class TestEmploye {
    public static void main(String[] args) {
        EmployeService es = new EmployeService();
        es.create(new Employe("younes", "younes", "0771207602"));
         es.create(new Employe("hamza", "hamza", "0771207602"));
          es.create(new Employe("imane", "imane", "0771207602"));
           es.create(new Employe(" reda", "reda", "0771207602"));
           
    }
    
}
