/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import ma.projet.classes.Tache;
import java.util.Date;
import ma.projet.services.ProjetService;
import ma.projet.services.TacheService;

/**
 *
 * @author PC
 */
public class TestTache {
    public static void main(String[] args) {
        TacheService ts = new TacheService();
        ProjetService ps = new ProjetService();
       ts.create(new Tache("mcd1", new Date(), new Date("123/1/01"), 1000, ps.getById(9)));
        ts.create(new Tache("msd 2", new Date(), new Date("123/11/01"), 1000, ps.getById(9)));
         ts.create(new Tache("mld 3", new Date(), new Date("13/8/02"), 1000, ps.getById(9)));
        
    }
}
