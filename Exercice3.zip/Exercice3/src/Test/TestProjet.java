/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import ma.projet.classes.Projet;
import java.util.Date;
import ma.projet.services.EmployeService;
import ma.projet.services.ProjetService;

/**
 *
 * @author PC
 */
public class TestProjet {
    public static void main(String[] args) {
        ProjetService ps = new ProjetService();
        EmployeService es = new EmployeService();
        ps.create(new Projet("app web", new Date(), new Date("127/10/18"), es.getById(1)));
        ps.create(new Projet("appp desktop", new Date(), new Date("127/10/18"), es.getById(2)));
    }
}
