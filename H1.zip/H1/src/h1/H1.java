
package h1;

import java.util.Date;
import ma.projet.entity.Produit;
import ma.projet.service.ProduitService;
import ma.projet.util.HibernateUtil;


public class H1 {

    
    public static void main(String[] args) {
         HibernateUtil.getSessionFactory();
        ProduitService pp = new ProduitService();
        Produit p_1 = new Produit("stylo", "1", new Date(124, 02, 04), 3.99, "dst1");
        Produit p_2 = new Produit("crayon", "2", new Date(120, 3, 2), 2, "dst2");
        Produit p_3 = new Produit("table", "3", new Date(121, 5, 3), 150.99, "dst3");
        Produit p_4 = new Produit("tshirt", "4", new Date(122, 8, 4), 109.99, "dst4");
        Produit p_5 = new Produit("chemise", "5", new Date(123, 11, 5), 226, "dst5");
        
        pp.create(p_1);
        pp.create(p_2);
        pp.create(p_3);
        pp.create(p_4);
        pp.create(p_5);
        
       
        System.out.println("\n*********************************affichage des produits***************************\n");
     
       for(Produit p : pp.getAll()){
          System.out.println("Produit " + String.valueOf(p.getReference()) + ": " + p.getMarque());
     }
        
        System.out.println("\n***************************affichage des infos du produit 2************************************************\n");
        Produit p2 = pp.getById(2);
        System.out.println("Margue: " + p2.getMarque());
        System.out.println("Referenc: " + p2.getReference());
        System.out.println("DateAchat: " + p2.getDateAchat());
        System.out.println("Prix: " + p2.getPrix()+ " DH");
        System.out.println("Designation: " + p2.getDesignation());
        
        System.out.println("\n***************************supprimer le produit 3************************************************\n");
        
        pp.delete(pp.getById(3));
    
        System.out.println("\n***************************modifier les info du produit 1************************************************\n");
   
        Produit p1 = pp.getById(1);
        p1.setDesignation("nouvelle Dst 1");
        pp.update(p1);
    
        
        System.out.println("\n***************liste produit done le pris >100*********************************************\n");
       
        for(Produit p : pp.getAll()){
            if(p.getPrix() > 100){
                System.out.println(p.getMarque());
            }
        }
        
        System.out.println("\nLa liste des produits commander entre 01/03/2023 et 01/08/2023\n");
        Date minDate = new Date(123, 4, 1);
        Date maxDate = new Date(124, 9, 1);
        
        for(Produit p : pp.getAll()){
            if( (maxDate.compareTo(p.getDateAchat()) == 1 || maxDate.compareTo(p.getDateAchat()) == 0)&& 
                    (minDate.compareTo(p.getDateAchat()) == -1 || minDate.compareTo(p.getDateAchat()) == 0)
        )
            {
                System.out.println(p.getMarque() + ", " + p.getDateAchat());
            }
    
        }
    
    }
    
    
 
}
